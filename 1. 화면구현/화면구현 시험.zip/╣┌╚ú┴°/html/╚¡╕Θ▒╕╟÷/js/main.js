window.addEventListener("DOMContentLoaded", function() {
  const swiper = new Swiper(".mySwiper", {
    pagination: {
      el: ".swiper-pagination",
    },
  });
});